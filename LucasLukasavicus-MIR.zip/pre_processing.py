# === IMPORTS =================================================================
import requests
import pandas as pd
import json
from datetime import datetime
import sys
# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

# === CONSTANTS ===============================================================
URL = "https://fiis.com.br/wp-json/fiis/v1/funds"

HEADERS={
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36',
    'Referer': 'https://fiis.com.br/vifi11/',

    'Accept': 'application/json, text/plain, */*',
    'Accept-Language': 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7,es;q=0.6',
    'Cache-Control': 'no-cache',
    'Cookie' : '_gcl_au=1.1.1401315928.1687872863; _fbp=fb.2.1687872864000.1852345747; _hjSessionUser_1049683=eyJpZCI6IjlkYmIwMDEzLTRkZGItNWM4Yi05MTllLTllNmZlMzNmMmZiOSIsImNyZWF0ZWQiOjE2ODc4NzI4NjQ3ODMsImV4aXN0aW5nIjp0cnVlfQ==; hubspotutk=5bdace1cc6859174ccd86739f2c67904; __hs_opt_out=no; __hssrc=1; _gid=GA1.3.410425610.1689279073; popup=popup-fiis.com; __hstc=109538586.5bdace1cc6859174ccd86739f2c67904.1687872914435.1689279109575.1689282439215.5; _ga=GA1.1.40554755.1687872863; _hjIncludedInSessionSample_1049683=0; _hjSession_1049683=eyJpZCI6IjRiMzhlZjA4LTc1MjktNDllZi1iYzc0LTNmNGMxOTliYjliNCIsImNyZWF0ZWQiOjE2ODkzNDIyNjQzMTYsImluU2FtcGxlIjpmYWxzZX0=; _hjAbsoluteSessionInProgress=0; _ga_NFCXE4NETS=GS1.1.1689342169.8.1.1689342318.60.0.0',
    'Pragma': 'no-cache',
    'Sec-Ch-Ua': '"Not.A/Brand";v="8", "Chromium";v="114", "Google Chrome";v="114"',
    'Sec-Ch-Ua-Mobile': '?0',
    'Sec-Ch-Ua-Platform': '"Windows"',
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'same-origin',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36',
    'X-Fiis-Nonce': '61495f60b533cc40ad822e054998a3190ea9bca0d94791a1da',
}
# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


# === CRAWL FUNCTIONS =========================================================
def crawl_fii_quotes(ticker):
  url = f"{URL}/{ticker}/quotes"
  req = requests.get(url, headers=HEADERS)

  assert req.status_code == 200, "Something went wrong with request"
  if(req.status_code != 200):
    print(req)
    raise Exception("Something bad happen")

  json_data_str = req.json()
  json_data = json.loads(json_data_str)
  json_data = json_data[0]
  quotes = json.loads(json_data['quotations'])

  # remove time from date
  for q  in quotes:
    q['date'] = datetime.strptime(q['date'][:8], "%d/%m/%y")

  return pd.DataFrame(quotes)

def crawl_fii_yields(ticker):
  url = f"{URL}/{ticker}/incomes"
  req = requests.get(url, headers=HEADERS)

  assert req.status_code == 200, "Something went wrong with request"
  if(req.status_code != 200):
    print(req)
    raise Exception("Something bad happen")

  json_data_str = req.json()
  json_data = json.loads(json_data_str)
  incomes = json_data['incomes']

  # remove time from date
  format = '%Y-%m-%d'
  for i  in incomes:
    i['data_base'] = datetime.strptime(i['data_base'], format)
    i['data_pagamento'] = datetime.strptime(i['data_pagamento'], format)

  return pd.DataFrame(incomes)

def crawl_fii_data(ticker):
  q = crawl_fii_quotes(ticker)
  y = crawl_fii_yields(ticker)
  return q, y
# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

# === DATA PIPELINE ===========================================================
def get_data_real_state_data(tickers):
    # Given a set of tickers

    # 1. Crawl the data
    # -------------------------------------------------------------------------
    ERRS = []
    data = []
    for t in tickers:
        # print(f"getting data for {t}")
        try:
            dfq, dfy = crawl_fii_data(t)
            data.append({
                'ticker' : t,
                'quotes' : dfq,
                'incomes': dfy
            })
        except Exception as e:
            ERRS.append({'step': 'crawl_fii_data', 'ticker' : t, 'err' : e})
    # -------------------------------------------------------------------------

    # 2. Join Data
    # -------------------------------------------------------------------------
    # Join Data for Prices
    # Get a set of dates (to join all prices based on these dates)
    dates = []
    for d in data:
        dts = list(d['quotes']['date'].unique())
        dates = list(set(dates+dts))

    prices_df = pd.DataFrame(dates, columns=['date']).sort_values(by= 'date')

    for d in data:
        quotes = d['quotes']
        tckr = d['ticker']
        prices_df = pd.merge(prices_df, quotes, on='date', how='left')
        prices_df[f"{tckr}_price"] = prices_df["price"]
        del prices_df["price"]

    prices_df.set_index('date')
    # .........................................................................
    dates = []
    for d in data:
        dts = list(d['incomes']['data_pagamento'].unique())
        dates = list(set(dates+dts))

    incomes_df = pd.DataFrame(dates, columns=['data_pagamento']).sort_values(by= 'data_pagamento')

    for d in data:
        incomes = d['incomes'][['data_pagamento', 'rendimento']]
        tckr = d['ticker']
        incomes_df = pd.merge(incomes_df, incomes, on='data_pagamento', how='left')
        incomes_df[f"{tckr}_rendimento"] = incomes_df["rendimento"]
        del incomes_df["rendimento"]

    incomes_df.set_index('data_pagamento')
    # -------------------------------------------------------------------------

    # 3. Export Data
    # -------------------------------------------------------------------------
    # incomes_df.to_csv('incomes.csv')
    # prices_df.to_csv('prices.csv')
    # -------------------------------------------------------------------------

    return (prices_df, incomes_df, ERRS)

# -----------------------------------------------------------------------------

def get_base_asset_data(file):
    ifix = pd.read_csv(file, header=1, encoding='latin1', sep=';', index_col=False)
    ifix = ifix.drop(ifix.tail(2).index)
    # tickers = list(ifix['Código'])

    # ifix['Qtde. Teórica']
    # sum(ifix['Part. (%)'])
    ifix['part'] = ifix['Part. (%)'].apply(lambda x : float(x.replace(',', '.')))
    ifix['theorical_qnt'] = ifix['Qtde. Teórica'].apply(lambda x : int(x.replace('.', '')))
    M = sum(ifix['theorical_qnt'])
    ifix['participation'] = ifix['theorical_qnt'] / M

    return ifix


def join_data(prices_df, ifix_df, ERRS=[]):
    prices_ifix_df = pd.DataFrame()
    prices_ifix_df['date'] = prices_df['date']
    # prices_df.columns[1:]
    tickers_and_parts_ifix = list(zip(ifix_df['Código'], ifix_df['part']))

    for t, p in tickers_and_parts_ifix:
        k = f"{t}_price"
        try:
            prices_ifix_df[t] =  prices_df[k] * p
        except Exception as e:
            ERRS.append({'step': 'ifix_composition', 'ticker' : t, 'err' : e})
            # errs.append(t)

    # .........................................................................

    all_prices_ifix = prices_ifix_df.sum(axis=1)
    ifix_prices = pd.DataFrame()
    ifix_prices['date'] = prices_ifix_df['date']
    ifix_prices['IFIX_price'] = all_prices_ifix

    # .........................................................................

    final_prices = pd.merge(prices_df, ifix_prices, on='date')
    final_prices.to_csv('final_prices.csv')
    return final_prices


def pipeline(file):
    # file = 'IFIXDia_17-07-23.csv'
    ifix_df = get_base_asset_data(file)
    tickers = list(ifix_df['Código'])

    pdf, idf, ERRS = get_data_real_state_data(tickers)

    all_assets_data = join_data(pdf, ifix_df, ERRS)

    return all_assets_data
# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++



def main(input_file, output_file='final_prices.csv'):
    try:
        df = pd.read_csv(output_file)
    except:
        df = pipeline(input_file)
    return df

if(__name__ == '__main__'):
    input_file = sys.args[1]
    output_file = sys.args[2]
    main(input_file, output_file)

# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++



