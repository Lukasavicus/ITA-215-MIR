import matplotlib.pyplot as plt
import seaborn as sns

def show_plot(df, fig_title):
  df.plot(x="date",figsize=(15,7), linewidth=3, title=fig_title)
  plt.grid()
  plt.show()

def show_correlation(df):
    cm = df.drop(columns=["date"]).corr()
    plt.figure(figsize=(16,16))
    ax=plt.subplot()
    sns.heatmap(cm, annot=True);
  
def show_hist(df, figsize=(10,10), bins=50):
  df.hist(figsize=figsize,bins=bins);

def show_scatter_base_vs_asset(df, base, asset):
   df.plot(kind = 'scatter', x = base, y = asset)

# usage: show_scatter_base_vs_asset(final_prices_daily_return, 'IFIX_price', 'CACR11_price')

def show_scatter_base_vs_asset_with_trendline(df, base, asset, alpha, beta):
   # Now let's plot the scatter plot and the straight line on one plot
    df.plot(kind = 'scatter', x = base, y = asset)

    # Straight line equation with alpha and beta parameters
    # Straight line equation is y = beta * rm + alpha
    plt.plot(df[base], beta*df[base]+alpha, '-', color = 'g')

# usage: show_scatter_base_vs_asset_with_trendline(final_prices_daily_return, 'IFIX_price', 'CACR11_price', alpha, beta)