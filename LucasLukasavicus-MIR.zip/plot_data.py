# from static_plot_data import show_plot as show_plot
from interactive_plot_data import show_plot, show_distplot

from static_plot_data import show_hist, show_scatter_base_vs_asset, show_scatter_base_vs_asset_with_trendline, show_correlation

# USAGE EXAMPLES:
# show_plot(prices_df, 'Preços dos FIIs x Tempo')
# show_plot(normalize(prices_df), 'Preços (Normalizados) dos FIIs x Tempo')

# Plot interactive chart
# interactive_plot(prices_df, "Preços (Gráfico Interativo)")

# Plot interactive (normalized) chart
# interactive_plot(normalize(prices_df), "Preços Normalizados (Gráfico Interativo)")

# show_plot(prices_daily_return, "stocks daily returns")
# interactive_plot(prices_daily_return, "stocks daily returns")